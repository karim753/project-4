<?php require "includes/header.php" ?>
<main>
    <h2>Deze pagina bestaat niet</h2>
    <a href="/">Ga terug naar de homepage</a>
</main>
<?php require "includes/footer.php" ?>