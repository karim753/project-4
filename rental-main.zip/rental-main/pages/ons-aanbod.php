<?php require "includes/header.php" ?>

<main>
    <h2>Ons aanbod</h2>
</main>
<?php require "includes/footer.php" ?>

